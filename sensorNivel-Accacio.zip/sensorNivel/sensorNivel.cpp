/*
 * sensorNivel.cpp   
 * disciplina: Controle Automatico II e III   
 * Autor: Accacio Santos   
 * data:  abril/2022
 */

# include "Arduino.h"
# include "sensorNivel.h"

sensorNivel::sensorNivel(int TRIG, int ECHO)
{
  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);
  Trig_pin = TRIG;
  Echo_pin = ECHO;
}

float sensorNivel::calcSensor()
{
  /* Envia Pulso de 5V por pelo menos 10us para iniciar medição.*/
  digitalWrite(Trig_pin, HIGH);
  delayMicroseconds(10);
  digitalWrite(Trig_pin, LOW);

  /* Mede quanto tempo o pino de echo ficou no estado alto, ou seja,
    o tempo de propagação da onda. */
  pulse_time = pulseIn(Echo_pin, HIGH);

  /* A distância entre o sensor ultrassom e o objeto será proporcional a velocidade
    do som no meio e a metade do tempo de propagação. Para o ar na
    temperatura ambiente Vsom = 0,0343 cm/us. */
  levelCM = 0.01715 * pulse_time;

  return levelCM;
}

