/*
 * sensorNivel.h
 * Autor: Accacio Santos
 * abril/2022
 * 
 */

 #ifndef sensorNivel_h
 #define sensorNivel_h

 # include "Arduino.h"

class sensorNivel 
{
  public:
      sensorNivel(int TRIG, int ECHO);
      float calcSensor();
  
  private:
     int   Trig_pin;
     int   Echo_pin;
     uint32_t pulse_time;
     float levelCM;
     
};

 #endif
